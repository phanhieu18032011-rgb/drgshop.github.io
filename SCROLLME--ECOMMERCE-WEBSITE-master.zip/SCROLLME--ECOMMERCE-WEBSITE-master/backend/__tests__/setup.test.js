// This file should only contain setup code, not tests.
require('@testing-library/jest-dom/extend-expect'); // For extended DOM assertions
